$(document).ready(function(){

    $(".an").on('click',function()
    {
        $(this).addClass("active-page");
    })

    $(".main1").click(function(){
        $(".list").slideToggle();
        $(".list").css({"display":"flex"})
    })

})
