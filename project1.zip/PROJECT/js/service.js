$(document).ready(function(){
    $("#nameCheck").hide();
    $("#pwdCheck").hide();
    $("#cpwdCheck").hide();
    $("#emailCheck").hide();
    $("#mbCheck").hide();


    let user_no_err = true;
    let mail_no_err = true;
    let mb_no_err = true;
    let pass_no_err = true;
    let cpwd_no_err = true;

    // USER NAME VALIDATION
    $("#name").keyup(function(){
        username_check();
    })

    function username_check()
    {
        let user_value=$("#name").val();
        let username_validation = RegExp ('^([A-Z]{1})([a-z]{2,20})([ ]{1})([A-Z]{1})([a-z]{2,20})$');
        console.log("User value: ",user_value);
        if(user_value.length == "")
        {
            $("#nameCheck").show();
            $("#nameCheck").html("**Required field.");
            $("#nameCheck").focus();
            $("#nameCheck").css("color","goldenrod");
            user_no_err = false;
            return false;
        }

        else if(!username_validation.test(user_value))
        {
            $("#nameCheck").show();
            $("#nameCheck").html("**Invalid Username.");
            $("#nameCheck").focus();
            $("#nameCheck").css("color","goldenrod");
            user_no_err = false;
            return false;
        }

        else
        {
            $("#nameCheck").hide();
            user_no_err = true;
            return true;
        }
    }

    // EMAIL VALIDATION
    $("#email").keyup(function(){
        mail_check();
    })

    function mail_check()
    {
        let mail_value = $("#email").val();
        let email_validation = RegExp ('^(?=.*[a-zA-Z])[0-9a-zA-Z]{4,20}([@]{1})([a-z0-9A-Z]{5,20})([.]{1})([a-zA-Z]{2,30})$')

        if (mail_value == "")
        {
            $("#emailCheck").show();
            $("#emailCheck").html("**required field.");
            $("#emailCheck").focus();
            $("#emailCheck").css("color","goldenrod");
            mail_no_err = false;
            return false;
        }

        else if (!email_validation.test(mail_value))
        {
            $("#emailCheck").show();
            $("#emailCheck").html("Please enter valid email address.");
            $("#emailCheck").focus();
            $("#emailCheck").css("color","goldenrod");
            mail_no_err = false;
            return false;
        }

        else
        {
            $("#emailCheck").hide();
            mail_no_err = true;
            return true;
        }
    }




    //MOBILE NO. VALIDATION
    $("#phn").keyup(function()
    {
        mb_check();
    })

    function mb_check()
    {
        let mb_value = $("#phn").val();
        let mb_validation = RegExp('^([6-9]{1})([0-9]{9})$');

        if (mb_value == "")
        {
            $("#mbCheck").show();
            $("#mbCheck").html("**required field.");
            $("#mbCheck").focus();
            $("#mbCheck").css("color","goldenrod");
            mb_no_err = false;
            return false;
        }

        else if (!mb_validation.test(mb_value))
        {
            $("#mbCheck").show();
            $("#mbCheck").html("Please enter valid phone no.");
            $("#mbCheck").focus();
            $("#mbCheck").css("color","goldenrod");
            mb_no_err = false;
            return false;
        }

        else
        {
            $("#mbCheck").hide();
            mb_no_err = true;
            return true;
        }
    }



    //PASSWORD VALIDATION
    $("#pwd").keyup(function(){
        pwd_check();
    })
    function pwd_check()
    {
        let pwd_value = $("#pwd").val();
        let pwd_validation = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%&?/])([a-zA-Z0-9!@#$%&?/]{8,15})$/
        if(pwd_value == "")
        {
            $("#pwdCheck").show();
            $("#pwdCheck").html("**Required field.");
            $("#pwdCheck").focus();
            $("#pwdCheck").css("color","goldenrod");
            pwd_no_err = false;
            return false;
        }

        else if (!pwd_validation.test(pwd_value))
        {
            $("#pwdCheck").show();
            $("#pwdCheck").html("**Wrong Password.Atlest 1 smallcase, 1 capitalcase, 1 special character and 1 number is required..");
            $("#pwdCheck").focus();
            $("#pwdCheck").css("color","goldenrod");
            pass_no_err = false;
            return false;
        }

        else
        {
            $("#pwdCheck").hide();
            pass_no_err = true;
            return pwd_value;
        }                         
    }



    //CONFIRM PASSWORD VALIDATION
    $("#cpwd").keyup(function(){
        cpwd_check();
    })

    function cpwd_check()
    {
        let cpwd_value = $("#cpwd").val();
        let correct_pwd = pwd_check();

        if(cpwd_value == "")
        {
            $("#cpwdCheck").show();
            $("#cpwdCheck").html("**Required field.");
            $("#cpwdCheck").focus();
            $("#cpwdCheck").css("color","goldenrod");
            cpwd_no_err = false;
            return false;
        }

        else if (cpwd_value != correct_pwd)

        {
            $("#cpwdCheck").show();
            $("#cpwdCheck").html("**password not recognized.");
            $("#cpwdCheck").focus();
            $("#cpwdCheck").css("color","goldenrod");
            cpwd_no_err = false;
            return false;
        }

        else
        {
            $("#cpwdCheck").hide();
            cpwd_no_err = true;
            return true;
        }

    }

    /* FORM SUBMISSION */
    $(".btn-submit").click(function()
    {
        // username_check();
        mail_check();
        // mb_check();
        pwd_check();
        // cpwd_check();

        // let user_no_err = true;
        let mail_no_err = true;
        // let mb_no_err = true;
        let pass_no_err = true;
        // let cpwd_no_err = true;
            

        // if (user_no_err = true && mail_no_err == true && pwd_no_err == true && cpwd_no_err == true)
        // {
        //     return true;
        // }
        // else if(user_no_err == true && mail_no_err == true && mb_no_err == true)
        // {
        //     return true;
        // }
        if (mail_no_err == true && pass_no_err == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    })



})
    // end of form validation
