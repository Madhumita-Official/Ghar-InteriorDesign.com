$(document).ready(function(){
    $(".imgBox").hover(function(){
        $(this).fadeToggle(2000);
    })


    $("#item1").hover(function()
    {
        $("#myText1").slideToggle(500);
        $("#myText1").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item2").hover(function()
    {
        $("#myText2").slideToggle(500);
        $("#myText2").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item3").hover(function()
    {
        $("#myText3").slideToggle(500);
        $("#myText3").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item4").hover(function()
    {
        $("#myText4").slideToggle(500);
        $("#myText4").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item5").hover(function()
    {
        $("#myText5").slideToggle(500);
        $("#myText5").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item6").hover(function()
    {
        $("#myText6").slideToggle(500);
        $("#myText6").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item7").hover(function()
    {
        $("#myText7").slideToggle(500);
        $("#myText7").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item8").hover(function()
    {
        $("#myText8").slideToggle(500);
        $("#myText8").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

    $("#item9").hover(function()
    {
        $("#myText9").slideToggle(500);
        $("#myText9").css({"display":"flex","justify-content":"center","align-items":"center"})
    })

})


AOS.init(
    {
      offset:150,
      duration:2000
    }
  );

